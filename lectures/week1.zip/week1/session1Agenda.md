# July 6th 2023 Agenda
# Week 1 Day 1

## Intros
## Rules of the classroom
## HTML